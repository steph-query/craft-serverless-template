import React from 'react';

const NotFound = () => {
  return (
    <span>Ooops!</span>
  )
};

export default NotFound;
