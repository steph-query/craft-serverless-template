import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';

import './App.css';

export class App extends Component {
  render() {
    return (
      <div>
      </div>
    );
  }
}

const mapStateToProps = null;
const mapActionsToProps = null;
export default connect(mapStateToProps, mapActionsToProps)(App);
